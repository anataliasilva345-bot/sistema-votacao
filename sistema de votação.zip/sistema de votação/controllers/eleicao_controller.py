from models.cargos import CARGOS
from models.eleicao import Eleicao
from models.repositorio import Repositorio
from controllers.auth_controller import AuthController


class EleicaoController:
    def __init__(self):
        self.repo = Repositorio()

    def cadastrar(self, nome, candidatos_ids: list):
        """Cria a eleição com os candidatos escolhidos.
        Os cargos da eleição são os cargos desses candidatos."""
        if not nome.strip():
            raise ValueError("Informe o nome da eleição.")
        ids = list(dict.fromkeys(candidatos_ids))  # sem repetidos, mantém ordem
        if not ids:
            raise ValueError("Selecione ao menos um candidato.")
        candidatos = self.repo.buscar_candidatos_por_ids(ids)
        if len(candidatos) != len(ids):
            raise ValueError("Algum candidato selecionado não existe mais.")

        cargos = sorted({c.cargo for c in candidatos},
                        key=lambda x: CARGOS.index(x) if x in CARGOS else len(CARGOS))
        e = Eleicao(nome.strip(), cargos, candidatos_ids=ids)
        self.repo.inserir_eleicao(e)
        self.repo.registrar_auditoria(
            AuthController.usuario_atual(), "CRIAR_ELEICAO",
            f"{nome} | {', '.join(cargos)} | candidatos nº: "
            f"{', '.join(str(c.numero) for c in candidatos)}")
        return e

    def listar(self):
        return self.repo.listar_eleicoes()

    def encerrar(self, eleicao_id):
        self.repo.atualizar_status_eleicao(eleicao_id, "ENCERRADA")
        self.repo.registrar_auditoria(
            AuthController.usuario_atual(), "ENCERRAR_ELEICAO", f"id={eleicao_id}")
