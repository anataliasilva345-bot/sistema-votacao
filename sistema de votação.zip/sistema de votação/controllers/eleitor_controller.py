from models.eleitor import Eleitor
from models.repositorio import Repositorio
from utils.validadores import validar_cpf
from controllers.auth_controller import AuthController
from utils import imagens


class EleitorController:
    def __init__(self):
        self.repo = Repositorio()

    def cadastrar(self, nome, cpf, titulo, foto=None, biometria=False):
        if not nome.strip():
            raise ValueError("Nome obrigatório.")
        if not validar_cpf(cpf):
            raise ValueError("CPF inválido.")
        if not titulo.strip().isdigit():
            raise ValueError("Título deve conter apenas números.")
        if self.repo.buscar_eleitor_por_titulo(titulo):
            raise ValueError("Já existe eleitor com esse título.")
        if self.repo.buscar_eleitor_por_cpf(cpf):
            raise ValueError("Já existe eleitor com esse CPF.")
        caminho_foto = None
        if foto:
            try:
                caminho_foto = imagens.salvar_foto(foto, titulo.strip(), "eleitor")
            except Exception:
                raise ValueError("Não foi possível ler a imagem escolhida.")
        eleitor = Eleitor(nome, cpf, titulo, foto=caminho_foto,
                          biometria=bool(biometria))
        self.repo.inserir_eleitor(eleitor)
        self.repo.registrar_auditoria(
            AuthController.usuario_atual(), "CRIAR_ELEITOR",
            f"título={titulo} nome={nome} foto={'sim' if caminho_foto else 'não'} "
            f"biometria={'sim' if biometria else 'não'}")
        return eleitor

    def excluir(self, eleitor_id):
        e = self.repo.buscar_eleitor_por_id(eleitor_id)
        if not e:
            raise ValueError("Eleitor não encontrado.")
        if e.ja_votou or self.repo.eleitor_tem_votos(eleitor_id):
            raise ValueError(
                f"{e.nome} não pode ser excluído: já votou. "
                f"Isso preserva o registro dos votos.")
        self.repo.excluir_eleitor(eleitor_id)
        imagens.remover_foto(e.foto)
        self.repo.registrar_auditoria(
            AuthController.usuario_atual(), "EXCLUIR_ELEITOR",
            f"título={e.titulo} nome={e.nome}")
        return e

    def listar(self):
        return self.repo.listar_eleitores()