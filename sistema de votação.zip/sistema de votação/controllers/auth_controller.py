from models.repositorio import Repositorio
from utils.seguranca import verificar_senha, hash_senha


class AuthController:
    """Guarda o usuário logado em memória durante a sessão."""

    _usuario_logado = None

    def __init__(self):
        self.repo = Repositorio()

    def login(self, usuario, senha):
        u = self.repo.buscar_usuario(usuario)
        if not u:
            raise ValueError("Usuário não encontrado.")
        if not verificar_senha(senha, u["salt"], u["senha_hash"]):
            raise ValueError("Senha incorreta.")
        AuthController._usuario_logado = usuario
        self.repo.registrar_auditoria(usuario, "LOGIN", "Login realizado")
        return True

    def logout(self):
        if AuthController._usuario_logado:
            self.repo.registrar_auditoria(
                AuthController._usuario_logado, "LOGOUT", "")
        AuthController._usuario_logado = None

    @classmethod
    def usuario_atual(cls):
        return cls._usuario_logado or "anonimo"

    def cadastrar_usuario(self, usuario, senha, papel="ADMIN"):
        if not usuario.strip() or len(senha) < 6:
            raise ValueError("Usuário vazio ou senha muito curta (mín. 6).")
        if self.repo.buscar_usuario(usuario):
            raise ValueError("Usuário já existe.")
        salt, h = hash_senha(senha)
        self.repo.inserir_usuario(usuario, h, salt, papel)
        self.repo.registrar_auditoria(
            self.usuario_atual(), "CRIAR_USUARIO", f"Novo usuário: {usuario}")