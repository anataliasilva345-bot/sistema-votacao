from models.voto import Voto
from models.repositorio import Repositorio
from controllers.auth_controller import AuthController


class VotoController:
    def __init__(self):
        self.repo = Repositorio()

    def registrar_voto(self, eleicao, cargo, titulo_eleitor,
                       numero_candidato=None, tipo="VALIDO"):
        if not eleicao.esta_aberta:
            raise ValueError("Eleição encerrada.")
        if cargo not in eleicao.cargos:
            raise ValueError(f"Cargo '{cargo}' não pertence a esta eleição.")

        eleitor = self.repo.buscar_eleitor_por_titulo(titulo_eleitor)
        if not eleitor:
            raise ValueError("Eleitor não encontrado.")
        if self.repo.eleitor_ja_votou_no_cargo(eleicao.id, cargo, eleitor.id):
            raise ValueError(f"Eleitor já votou para {cargo} nesta eleição.")

        candidato_id = None

        if tipo == "VALIDO":
            if not numero_candidato or not str(numero_candidato).strip().isdigit():
                raise ValueError("Informe o número do candidato.")
            # ✅ Busca composta: número + cargo (mesma chave única do banco)
            candidato = self.repo.buscar_candidato_por_numero_e_cargo(
                int(numero_candidato), cargo)
            if not candidato:
                tipo = "NULO"
            elif candidato.cargo != cargo:
                raise ValueError(
                    f"Candidato nº {candidato.numero} concorre a '{candidato.cargo}', "
                    f"não a '{cargo}'.")
            elif not eleicao.aceita_candidato(candidato.id):
                # candidato existe, mas não foi escolhido para esta eleição
                tipo = "NULO"
            else:
                candidato_id = candidato.id
        elif tipo not in ("BRANCO", "NULO"):
            raise ValueError("Tipo de voto inválido.")

        voto = Voto(eleicao.id, cargo, eleitor.id, candidato_id, tipo)
        self.repo.inserir_voto(voto)
        if candidato_id:
            self.repo.incrementar_voto_candidato(candidato_id)
        self.repo.marcar_eleitor_votou(eleitor.id)
        self.repo.registrar_auditoria(
            AuthController.usuario_atual(), "REGISTRAR_VOTO",
            f"eleição={eleicao.id} cargo={cargo} eleitor={eleitor.titulo} tipo={tipo}")
        return voto

    def buscar_eleitor(self, titulo):
        titulo = str(titulo).strip()
        if not titulo:
            return None
        return self.repo.buscar_eleitor_por_titulo(titulo)

    def buscar_candidato(self, numero, cargo=None):
        """Usado pela tela de votação para pré-visualizar o candidato.
        Se `cargo` for informado, busca pelo par (número, cargo); caso
        contrário, retorna o primeiro candidato com esse número."""
        numero = str(numero).strip()
        if not numero.isdigit():
            return None
        if cargo:
            return self.repo.buscar_candidato_por_numero_e_cargo(int(numero), cargo)
        lista = self.repo.listar_candidatos_por_numero(int(numero))
        return lista[0] if lista else None

    def apurar(self, eleicao):
        por_cargo = {}
        for cargo in eleicao.cargos:
            candidatos = [c for c in self.repo.listar_candidatos(cargo)
                          if eleicao.aceita_candidato(c.id)]
            # Votos de cada candidato contados só nesta eleição (o contador
            # global em candidatos.votos mistura eleições diferentes).
            contagem = self.repo.votos_por_candidato(eleicao.id, cargo)
            for c in candidatos:
                c.votos = contagem.get(c.id, 0)
            ranking = sorted(candidatos, key=lambda c: c.votos, reverse=True)
            brancos = self.repo.total_votos(eleicao.id, cargo, "BRANCO")
            nulos = self.repo.total_votos(eleicao.id, cargo, "NULO")
            por_cargo[cargo] = {
                "ranking": ranking,
                "validos": sum(c.votos for c in ranking),
                "brancos": brancos,
                "nulos": nulos,
                "total": self.repo.total_votos(eleicao.id, cargo),
            }
        return {"por_cargo": por_cargo}