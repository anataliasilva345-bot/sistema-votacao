from models.candidato import Candidato
from models.cargos import CARGOS
from models.repositorio import Repositorio
from controllers.auth_controller import AuthController
from utils import imagens
from utils.validadores import normalizar_nome


class CandidatoController:
    def __init__(self):
        self.repo = Repositorio()

    def cadastrar(self, nome, numero, partido, cargo, foto=None):
        if not nome.strip() or not partido.strip() or not cargo.strip():
            raise ValueError("Preencha todos os campos.")
        if cargo not in CARGOS:
            raise ValueError("Cargo inválido.")
        if not str(numero).isdigit():
            raise ValueError("Número deve ser inteiro.")
        if int(numero) <= 0:
            raise ValueError("O número do candidato deve ser maior que zero.")

        # Regra: número único SOMENTE dentro do mesmo cargo
        existente = self.repo.buscar_candidato_por_numero_e_cargo(int(numero), cargo)
        if existente:
            raise ValueError(
                f"O número {int(numero)} já pertence a {existente.nome} "
                f"no cargo de {cargo}.")

        nome_norm = normalizar_nome(nome)
        for c in self.repo.listar_candidatos():
            if normalizar_nome(c.nome) == nome_norm:
                raise ValueError(
                    f"Já existe um candidato chamado {c.nome} (nº {c.numero}).")

        caminho_foto = None
        if foto:
            try:
                # ✅ Nome do arquivo inclui o cargo → evita colisão quando o
                # mesmo número é usado em cargos diferentes
                caminho_foto = imagens.salvar_foto(foto, f"{int(numero)}_{cargo}")
            except Exception:
                raise ValueError("Não foi possível ler a imagem escolhida.")

        c = Candidato(nome, int(numero), partido, cargo, foto=caminho_foto)
        self.repo.inserir_candidato(c)
        self.repo.registrar_auditoria(
            AuthController.usuario_atual(), "CRIAR_CANDIDATO",
            f"nº={numero} nome={nome} cargo={cargo}")
        return c

    def excluir(self, candidato_id):
        c = self.repo.buscar_candidato_por_id(candidato_id)
        if not c:
            raise ValueError("Candidato não encontrado.")
        eleicoes = self.repo.eleicoes_do_candidato(candidato_id)
        if eleicoes or self.repo.candidato_tem_votos(candidato_id):
            nomes = ", ".join(f"'{n}'" for n in eleicoes) or "com votos registrados"
            raise ValueError(
                f"{c.nome} não pode ser excluído: participa de eleição ({nomes}). "
                f"Isso preserva a apuração.")
        self.repo.excluir_candidato(candidato_id)
        imagens.remover_foto(c.foto)
        self.repo.registrar_auditoria(
            AuthController.usuario_atual(), "EXCLUIR_CANDIDATO",
            f"nº={c.numero} nome={c.nome} cargo={c.cargo}")
        return c

    def listar(self, cargo=None):
        return self.repo.listar_candidatos(cargo)